package com.example.seepeaker.fragment;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;

import com.example.seepeaker.activity.PracticeActivity;
import com.example.seepeaker.R;

import java.util.ArrayList;
import java.util.List;

// 하단 바의 홈 부분
public class HomeFragment extends Fragment {

    public HomeFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.fragment_home, container, false);

        List<String> cardViewModels = new ArrayList<>();
        cardViewModels.add("유저: Minjea");

        ViewPager2 viewPager = rootView.findViewById(R.id.viewpager2_home);
        Adapter cardViewAdapter = new Adapter(cardViewModels, requireContext());
        viewPager.setAdapter(cardViewAdapter);
        viewPager.setPadding(30, 0, 30, 0);

        return rootView;
    }

    class Adapter extends RecyclerView.Adapter<Adapter.AdapterViewHolder> {
        private final List<String> cardViewModels;
        private final Context cardViewContext;

        public Adapter(List<String> cardViewModels, Context cardViewContext) {
            this.cardViewModels = cardViewModels;
            this.cardViewContext = cardViewContext;
        }

        @NonNull
        @Override
        public AdapterViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_fragment_home_card, parent, false);
            Button buttonA = v.findViewById(R.id.buttonChangeActivity);
            buttonA.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(getContext(), PracticeActivity.class);
                    startActivity(intent);
                }
            });
            return new AdapterViewHolder(v);
        }

        @Override
        public void onBindViewHolder(@NonNull AdapterViewHolder holder, int position) {
            String cardViewItem = cardViewModels.get(position);
            holder.cardViewTitle.setText(cardViewItem);
        }

        @Override
        public int getItemCount() {
            return cardViewModels != null ? cardViewModels.size() : 0;
        }

        public class AdapterViewHolder extends RecyclerView.ViewHolder {
            TextView cardViewTitle;
            public AdapterViewHolder(View view) {
                super(view);
                cardViewTitle = view.findViewById(R.id.cardViewTitle);
            }
        }
    }
}