package com.example.seepeaker.fragment;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;

import com.example.seepeaker.R;
import com.example.seepeaker.activity.TestActivity;

import java.util.ArrayList;
import java.util.List;

// 하단 바의 시험 부분
public class TestFragment extends Fragment {

    public TestFragment() {
        // Required empty public constructor
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_home, container, false);

        // Sample data for ViewPager
        List<String> cardViewModels = new ArrayList<>();
        cardViewModels.add("유저: Minjea");
        String cardViewButtonText = getResources().getString(R.string.cardview_button_change_activity_text);

        // Initialize ViewPager2 and set its adapter
        ViewPager2 viewPager = rootView.findViewById(R.id.viewpager2_home);
        TestFragment.Adapter cardViewAdapter = new TestFragment.Adapter(cardViewModels, requireContext(), cardViewButtonText);
        viewPager.setAdapter(cardViewAdapter);
        viewPager.setPadding(30, 0, 30, 0);

        return rootView;
    }

    // RecyclerView Adapter
    class Adapter extends RecyclerView.Adapter<TestFragment.Adapter.AdapterViewHolder> {
        private final List<String> cardViewModels;
        private final Context cardViewContext;
        private String cardViewButtonText;

        public Adapter(List<String> cardViewModels, Context cardViewContext, String cardViewButtonText) {
            this.cardViewModels = cardViewModels;
            this.cardViewContext = cardViewContext;
            this.cardViewButtonText = cardViewButtonText;
        }

        @NonNull
        @Override
        public TestFragment.Adapter.AdapterViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_fragment_home_card, parent, false);
            Button buttonA = v.findViewById(R.id.buttonChangeActivity);
            buttonA.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(getContext(), TestActivity.class);
                    startActivity(intent);
                }
            });
            return new TestFragment.Adapter.AdapterViewHolder(v);
        }

        @Override
        public void onBindViewHolder(@NonNull TestFragment.Adapter.AdapterViewHolder holder, int position) {
            String cardViewItem = cardViewModels.get(position);
            holder.cardViewTitle.setText(cardViewItem);
            holder.changeActivityButtonText.setText(cardViewButtonText);
        }

        @Override
        public int getItemCount() {
            return cardViewModels != null ? cardViewModels.size() : 0;
        }

        public class AdapterViewHolder extends RecyclerView.ViewHolder {
            TextView cardViewTitle;
            TextView changeActivityButtonText;

            public AdapterViewHolder(View view) {
                super(view);
                cardViewTitle = view.findViewById(R.id.cardViewTitle);
                changeActivityButtonText = view.findViewById(R.id.buttonChangeActivity);
            }
        }
    }
}