package com.example.seepeaker.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import com.example.seepeaker.CustomListViewAdapter;
import com.example.seepeaker.R;
import com.example.seepeaker.activity.ReviewNotesActivity;

// 하단 바의 유저 부분
public class UserFragment extends Fragment {

    public UserFragment() { }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_user, container, false);

        // 리스트 뷰에 넣을 데이터 가져오기
        String[] rowTitle = getResources().getStringArray(R.array.user_info_arrays);
        String[] rowData = getResources().getStringArray(R.array.user_info_arrays2);

        // 리스트 뷰에서 사용할 어뎁터 가져오기
        ListView listView = rootView.findViewById(R.id.listView);
        CustomListViewAdapter adapter = new CustomListViewAdapter(requireContext(), rowTitle, rowData);
        listView.setAdapter(adapter);

        // 리스트 뷰의 아이템(각각의 행)을 누를시 작동
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // 오답 노트 보기가 클릭 됬을시 오답노트(Review Notes) Activity 로 전환
                if (rowTitle[position].equals("오답 노트 보기")) {
                    Toast.makeText(requireContext(), "오답 노트 보기", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(requireContext(), ReviewNotesActivity.class);
                    startActivity(intent);
                }
            }
        });

        // 개별 아이템(각각의 행)의 높이를 기준으로 전체 높이를 계산 여백? 방지
        int totalHeight = 0;
        for (int i = 0; i < adapter.getCount(); i++) {
            View listItem = adapter.getView(i, null, listView);
            listItem.measure(
                    View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
                    View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
            );
            totalHeight += listItem.getMeasuredHeight();
        }

        // 계산된 높이를 ListView의 레이아웃 높이로 설정
        listView.getLayoutParams().height = totalHeight + (listView.getDividerHeight() * (adapter.getCount() - 1));
        listView.requestLayout();

        return rootView;
    }
}

