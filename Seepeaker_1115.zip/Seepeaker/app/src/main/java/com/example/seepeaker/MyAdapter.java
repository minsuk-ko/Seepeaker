package com.example.seepeaker;

import android.content.Context;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

public class MyAdapter extends ArrayAdapter<String> {
    private final Context context;
    private final String[] mTitle;
    private final String[] mData;

    public MyAdapter(Context context, String[] mTitle, String[] mData) {
        super(context, 0, mTitle);
        this.context = context;
        this.mTitle = mTitle;
        this.mData = mData;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.user_info_list, parent, false);
        }

        TextView myTitle = convertView.findViewById(R.id.mTitle);
        TextView myData = convertView.findViewById(R.id.mData);

        myTitle.setText(mTitle[position]);
        myData.setText(mData[position]);

        // Check if the current item is "Item 1"
        if (mTitle[position].equals("오답 노트 보기")) {
            // Change the font color and style for "Item 1"
            myTitle.setTextColor(context.getResources().getColor(R.color.blue));
            myTitle.setTypeface(null, Typeface.BOLD);
        } else {
            // Reset font color and style for other items
            myTitle.setTextColor(context.getResources().getColor(android.R.color.black));
            myTitle.setTypeface(null, Typeface.NORMAL);
            myData.setTextColor(context.getResources().getColor(android.R.color.black));
            myData.setTypeface(null, Typeface.NORMAL);
        }

        return convertView;
    }
}
