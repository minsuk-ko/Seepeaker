package com.example.seepeaker;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

public class UserFragment extends Fragment {

    public UserFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout XML for this fragment
        View rootView = inflater.inflate(R.layout.fragment_user, container, false);

        // Sample data for the ListView
        String[] mTitle = getResources().getStringArray(R.array.user_info_arrays);
        String[] mData = getResources().getStringArray(R.array.user_info_arrays2);

        // Create a custom adapter and set it for the ListView
        ListView listView = rootView.findViewById(R.id.listView);
        MyAdapter adapter = new MyAdapter(requireContext(), mTitle, mData);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // Check if the clicked item is "Item 1"
                if (mTitle[position].equals("오답 노트 보기")) {
                    // Perform a specific action (e.g., show a Toast message) for "Item 1"
                    Toast.makeText(requireContext(), "오답 노트 보기", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(requireContext(), ReviewNotesActivity.class);
                    startActivity(intent);
                }
            }
        });

        // Calculate the total height based on the heights of individual items
        int totalHeight = 0;
        for (int i = 0; i < adapter.getCount(); i++) {
            View listItem = adapter.getView(i, null, listView);
            listItem.measure(
                    View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
                    View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
            );
            totalHeight += listItem.getMeasuredHeight();
        }

// Set the calculated height as the layout height of the ListView
        listView.getLayoutParams().height = totalHeight + (listView.getDividerHeight() * (adapter.getCount() - 1));
        listView.requestLayout();

// Wait for the layout to be drawn and adjust the height
        listView.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {
                // Remove the listener to avoid multiple calls
                listView.getViewTreeObserver().removeOnGlobalLayoutListener(this);

                // Calculate the total height again after the layout is drawn
                int newTotalHeight = 0;
                for (int i = 0; i < adapter.getCount(); i++) {
                    View listItem = adapter.getView(i, null, listView);
                    listItem.measure(
                            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
                            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
                    );
                    newTotalHeight += listItem.getMeasuredHeight();
                }

                // Set the new calculated height
                listView.getLayoutParams().height = newTotalHeight + (listView.getDividerHeight() * (adapter.getCount() - 1));
                listView.requestLayout();
            }
        });

        return rootView;
    }
}

