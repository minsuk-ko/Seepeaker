package com.example.seepeaker.activity;

import android.os.Bundle;
import android.view.View;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.seepeaker.CustomListViewAdapter;
import com.example.seepeaker.R;

// TestActivity의 결과를 보여 주는 부분
public class TestResultActivity extends AppCompatActivity {

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_review_notes);

        // 리스트 뷰에서 사용할 어뎁터 가져오기
        String[] rowTitle = getResources().getStringArray(R.array.review_notes_arrays);
        String[] rowData = getResources().getStringArray(R.array.test_result_arrays);

        // 리스트 뷰의 아이템(각각의 행)을 누를시 작동
        ListView listView = findViewById(R.id.listView);
        CustomListViewAdapter adapter = new CustomListViewAdapter(this, rowTitle, rowData);
        listView.setAdapter(adapter);

        // 개별 아이템(각각의 행)의 높이를 기준으로 전체 높이를 계산 여백? 방지
        int totalHeight = 0;
        for (int i = 0; i < adapter.getCount(); i++) {
            View listItem = adapter.getView(i, null, listView);
            listItem.measure(
                    View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
                    View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
            );
            totalHeight += listItem.getMeasuredHeight();
        }

        // 계산된 높이를 ListView의 레이아웃 높이로 설정
        listView.getLayoutParams().height = totalHeight + (listView.getDividerHeight() * (adapter.getCount() - 1));
        listView.requestLayout();
    }

}