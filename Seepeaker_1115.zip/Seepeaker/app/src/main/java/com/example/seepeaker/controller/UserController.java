package com.example.seepeaker.controller;

import com.example.seepeaker.model.User;
public class UserController {
    private User user;
    public UserController(User user){
        this.user = user;
    }
    public void updateUserInfo(String name, String email, int minScore, int maxScore, int avgScore, int testTime) {
        user.setUserName(name);
        user.setUserEmail(email);
        user.setMinScore(minScore);
        user.setMaxScore(maxScore);
        user.setAvgScore(avgScore);
        user.setTestTime(testTime);

        // Firebase 또는 다른 저장소에 업데이트하는 로직 필요
    }
}
