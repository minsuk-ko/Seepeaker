package com.example.seepeaker;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class ReviewNotesActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_review_notes);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar); // Set the activity's app bar
        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true); // Enable the back button in the app bar

        ListView listView = findViewById(R.id.listView);

        // Sample data for the ListView
        String[] mTitle = getResources().getStringArray(R.array.review_notes_arrays);
        String[] mData = getResources().getStringArray(R.array.review_notes_arrays2);

        // Create a custom adapter and set it for the ListView
        MyAdapter adapter = new MyAdapter(this, mTitle, mData);
        listView.setAdapter(adapter);

        // Calculate the total height based on the heights of individual items
        int totalHeight = 0;
        for (int i = 0; i < adapter.getCount(); i++) {
            View listItem = adapter.getView(i, null, listView);
            listItem.measure(
                    View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
                    View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
            );
            totalHeight += listItem.getMeasuredHeight();
        }

        // Set the calculated height as the layout height of the ListView
        listView.getLayoutParams().height = totalHeight + (listView.getDividerHeight() * (adapter.getCount() - 1));
        listView.requestLayout();
    }

    @SuppressLint("NonConstantResourceId")
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        Intent intent = new Intent(ReviewNotesActivity.this, MainActivity.class);
        startActivity(intent);
        finish();
        return true;
    }

}