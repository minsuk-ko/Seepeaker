package com.example.seepeaker.activity;

import android.os.Bundle;
        import android.view.View;
        import android.widget.Button;
        import android.widget.EditText;
        import android.widget.Toast;

        import androidx.appcompat.app.AppCompatActivity;

import com.example.seepeaker.R;

public class membershipActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_membership);

        EditText emailEditText = findViewById(R.id.edit_text_email);
        EditText idEditText = findViewById(R.id.edit_text_id);
        EditText passwordEditText = findViewById(R.id.edit_text_login_password);
        Button joinButton = findViewById(R.id.button_join);

        joinButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = emailEditText.getText().toString();
                String id = idEditText.getText().toString();
                String password = passwordEditText.getText().toString();
                
            }
        });
    }
}
