package com.example.seepeaker.activity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.seepeaker.R;

// 시험보기 부분 (MainActivity의 TestFragment 부분의 "시험 보기"를 누르면 나오는 Activity)
public class TestActivity extends AppCompatActivity {

    private ImageButton imageButton;
    private ProgressBar progressBar;
    private TextView textView;
    private boolean isListening = false;
    private boolean isAnswerCorrect = true; // 이 값은 정답인지 여부에 따라 설정
    private Handler blinkingHandler = new Handler();
    private boolean isTextVisible = false;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test);

        imageButton = findViewById(R.id.imageButton);
        progressBar = findViewById(R.id.progressBar3);
        textView = findViewById(R.id.textView4);

        progressBar.setVisibility(View.GONE); // 초기에 프로그래스 바 숨김
        textView.setVisibility(View.GONE); // 초기에 "듣고있어요" 숨김

        progressBar.setMax(100); // 프로그래스 바 최대값 설정

        imageButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v) {
                imageButton.setVisibility(View.GONE); // 이미지 버튼 숨기기
                textView.setVisibility(View.VISIBLE); // "듣고있어요" 보이기

                // 0.5초마다 "듣고있어요" 텍스트 깜빡이게 하기
                startBlinkingText();

                progressBar.setProgress(0); // 프로그래스 바 초기값 설정
                progressBar.setVisibility(View.VISIBLE); // 프로그래스 바 표시

                // 시뮬레이션을 위해 3초 동안 프로그래스 바를 증가시킴
                simulateProgressBarProgress();
            }
        });

    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    private void startBlinkingText() {
        isTextVisible = true;
        blinkingHandler.post(blinkingRunnable);
    }

    private void stopBlinkingText() {
        isTextVisible = false;
        blinkingHandler.removeCallbacks(blinkingRunnable);
    }

    private Runnable blinkingRunnable = new Runnable() {
        @Override
        public void run() {
            if (isTextVisible) {
                textView.setVisibility(View.INVISIBLE);
            } else {
                textView.setVisibility(View.VISIBLE);
            }
            isTextVisible = !isTextVisible;
            blinkingHandler.postDelayed(this, 500); // 0.5초 간격으로 깜빡임
        }
    };

    private void simulateProgressBarProgress() {
        final int totalTime = 3000; // 시뮬레이션에 사용할 시간 (3초)
        final int updateInterval = 50; // 0.05초마다 업데이트
        final int maxProgress = 100;
        final int progressIncrement = (maxProgress * updateInterval) / totalTime;
        final Handler progressHandler = new Handler();
        final Runnable progressRunnable = new Runnable() {
            int progress = 0;

            @Override
            public void run() {
                if (progress < maxProgress) {
                    progress += progressIncrement;
                    progressBar.setProgress(progress); // 프로그래스 바 업데이트
                    progressHandler.postDelayed(this, updateInterval);
                } else {
                    progressBar.setVisibility(View.GONE); // 프로그래스 바 숨기기
                    stopBlinkingText(); // 깜빡임 중지
                    textView.setVisibility(View.GONE); // "듣고있어요" 숨기기

                    // 정답 또는 오답 메시지 표시
                    if (isAnswerCorrect) {
                        showToast("테스트 완료");
                        Intent intent = new Intent(TestActivity.this, TestResultActivity.class); // CurrentActivity와 NewActivity를 각각 현재 액티비티와 전환할 액티비티에 맞게 변경해야 합니다.
                        startActivity(intent);
                    } else {
                        showToast("테스트 중지!");

                    }

                    // 이미지 버튼 다시 표시
                    imageButton.setVisibility(View.VISIBLE);
                }
            }
        };

        progressBar.setMax(maxProgress); // 프로그래스 바 최대값 설정
        progressHandler.post(progressRunnable);
    }
    @SuppressLint("NonConstantResourceId")
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        Intent intent = new Intent(TestActivity.this, MainActivity.class);
        startActivity(intent);
        finish();
        return true;
    }
}