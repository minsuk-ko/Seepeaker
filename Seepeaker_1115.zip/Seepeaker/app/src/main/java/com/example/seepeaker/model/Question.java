package com.example.seepeaker.model;

public class Question {
    private int testId;
    private int userId;
    private int wordId;
    private boolean checkAnswer;

    public Question() {
    }

    public Question(int testId,int userId,int wordId,boolean checkAnswer) {
        this.testId = testId;
        this.userId = userId;
        this.wordId = wordId;
        this.checkAnswer = checkAnswer;
    }

    public int getTestId() {
        return testId;
    }

    public void setTestId(int testId) {
        this.testId = testId;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public int getWordId() {
        return wordId;
    }

    public void setWordId(int wordId) {
        this.wordId = wordId;
    }

    public boolean isCheckAnswer() {
        return checkAnswer;
    }

    public void setCheckAnswer(boolean checkAnswer) {
        this.checkAnswer = checkAnswer;
    }
}
