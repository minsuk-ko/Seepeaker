package com.example.seepeaker;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class PronunciateHowtoActivity extends AppCompatActivity {

    Button button1, button2;
    ImageView imageView1, imageView2;

    TextView textView1, textView2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.howto_pronunciate);

        button1 = findViewById(R.id.buttonB);
        button2 = findViewById(R.id.buttonC);
        imageView1 = findViewById(R.id.imageViewToShow1);
        imageView2 = findViewById(R.id.imageViewToShow2);
        textView1 = findViewById(R.id.textViewToShow1);
        textView2= findViewById(R.id.textViewToShow2);

        button1.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {
                if ((imageView1.getVisibility() == View.VISIBLE)&&(textView1.getVisibility()==View.VISIBLE)) {
                    imageView1.setVisibility(View.INVISIBLE);
                } else {
                    imageView1.setVisibility(View.VISIBLE);
                    textView1.setVisibility(View.VISIBLE);
                }
            }
        });
        button2.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {
                if ((imageView2.getVisibility() == View.VISIBLE)&&(textView2.getVisibility()==View.VISIBLE)) {
                    imageView2.setVisibility(View.INVISIBLE);
                } else {
                    imageView2.setVisibility(View.VISIBLE);
                    textView2.setVisibility(View.VISIBLE);
                }
            }
        });



    }
}

