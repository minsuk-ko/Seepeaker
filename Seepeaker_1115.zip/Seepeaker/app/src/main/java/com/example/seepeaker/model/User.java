package com.example.seepeaker.model;


public class User {
    private int userId;
    private String userName;
    private String userEmail;
    private int minScore;
    private int maxScore;
    private int avgScore;
    private int testTime;
    public User(){}
    public User(int userId, String userName, String userEmail){
        this.userId = userId;
        this.userName = userName;
        this.userEmail= userEmail;
    }
    public User(int minScore,int maxScore,int avgScore,int testTime){
        this.minScore=minScore;
        this.maxScore=maxScore;
        this.avgScore=avgScore;
        this.testTime=testTime;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public int getUserId() {
        return userId;
    }

    public int getTestTime() {
        return testTime;
    }

    public void setTestTime(int testTime) {
        this.testTime = testTime;
    }

    public int getAvgScore() {
        return avgScore;
    }

    public void setAvgScore(int avgScore) {
        this.avgScore = avgScore;
    }

    public int getMaxScore() {
        return maxScore;
    }

    public void setMaxScore(int maxScore) {
        this.maxScore = maxScore;
    }

    public int getMinScore() {
        return minScore;
    }

    public void setMinScore(int minScore) {
        this.minScore = minScore;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }
}
