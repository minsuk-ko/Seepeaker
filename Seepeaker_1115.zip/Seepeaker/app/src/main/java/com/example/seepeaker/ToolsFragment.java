package com.example.seepeaker;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class ToolsFragment extends Fragment {

    private TextView textView;
    private Button buttonA, buttonB, buttonC;
    private ImageView imageView;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.extra_card, container, false);

        // 여기서 XML 레이아웃의 요소들을 참조하고 조작할 수 있습니다.
        // 예를 들어:
        TextView cardViewTitle = view.findViewById(R.id.cardViewTitle);
        Button buttonA= view.findViewById(R.id.buttonA);
        Button buttonB= view.findViewById(R.id.buttonB);
        Button buttonC= view.findViewById(R.id.buttonC);
        ImageView imageView1 = view.findViewById(R.id.imageViewToShow);

        buttonA.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {
                Toast.makeText(getContext(),"오답노트를 초기화하였습니다.",Toast.LENGTH_LONG).show();
            }
        });
        buttonB.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {
                if (imageView1.getVisibility() == View.VISIBLE) {
                    imageView1.setVisibility(View.INVISIBLE);
                } else {
                    imageView1.setVisibility(View.VISIBLE);
                }
            }
        });
        buttonC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getContext(), PronunciateHowtoActivity.class);
                startActivity(intent);
            }
        });

        return view;
    }
}
