package com.example.seepeaker.activity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.seepeaker.R;

// 발음도우미 부분 (MainActivity의 ToolsFragment 부분의 "발음 방법 도우미 열기"를 누르면 나오는 Activity)
public class PronunciationHelpActivity extends AppCompatActivity {
    //Consonant은 자음, Vowe는 모음임
    Button buttonConsonantImage, buttonVoweImage;
    ImageView imageViewConsonant, imageViewVowe;
    TextView textViewConsonant, textViewVowe;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pronunciation_help);

        buttonConsonantImage = findViewById(R.id.buttonConsonantImageOpen);
        buttonVoweImage = findViewById(R.id.buttonVoweImageOpen);
        imageViewConsonant = findViewById(R.id.imageConsonant);
        imageViewVowe = findViewById(R.id.imageVowe);
        textViewConsonant = findViewById(R.id.textConsonant);
        textViewVowe = findViewById(R.id.textVowe);

        //자음 버튼 클릭시 이미지 및 텍스트 보이기
        buttonConsonantImage.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                if ((imageViewConsonant.getVisibility() == View.VISIBLE)&&(textViewConsonant.getVisibility()==View.VISIBLE)) {
                    imageViewConsonant.setVisibility(View.INVISIBLE);
                } else {
                    imageViewConsonant.setVisibility(View.VISIBLE);
                    textViewConsonant.setVisibility(View.VISIBLE);
                }
            }
        });

        //모음 버튼 클릭시 이미지 및 텍스트 보이기
        buttonVoweImage.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                if ((imageViewVowe.getVisibility() == View.VISIBLE)&&(textViewVowe.getVisibility()==View.VISIBLE)) {
                    imageViewVowe.setVisibility(View.INVISIBLE);
                } else {
                    imageViewVowe.setVisibility(View.VISIBLE);
                    textViewVowe.setVisibility(View.VISIBLE);
                }
            }
        });


    }
}

