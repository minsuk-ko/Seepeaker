package com.example.seepeaker.activity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.MenuItem;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.example.seepeaker.R;
import com.google.firebase.firestore.FirebaseFirestore;

// 툴바의 로그인 부분
public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        FirebaseFirestore db = FirebaseFirestore.getInstance();

        Toolbar toolbarLogin = findViewById(R.id.toolbar_login);
        setSupportActionBar(toolbarLogin); // Activity 의 앱 바 설정
        ActionBar actionbarLogin = getSupportActionBar();
        actionbarLogin.setDisplayHomeAsUpEnabled(true); // Main Activity 로 되돌아 가기에 사용할 화살표를 표시함.
    }

    @SuppressLint("NonConstantResourceId")
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        //로그인 확인 부분
        SharedPreferences preferences = getSharedPreferences("LoginPrefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putBoolean("isLoggedOut", false);
        editor.apply();

        Intent intent = new Intent(LoginActivity.this, MainActivity.class);
        intent.putExtra("loginStateChange", true);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP); // Activity 꼬임? 방지 - 자세한 내용은 직접 찾아 볼것.
        intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP); // Activity 가 스택에 남아 있으면 onCreate 를하지 않음.
        startActivity(intent);
        finish();
        return true;
    }
}