package com.example.seepeaker;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;

import java.util.ArrayList;
import java.util.List;


public class HomeFragment extends Fragment {

    public HomeFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_home, container, false);

        // Sample data for ViewPager
        List<String>    cardViewModels = new ArrayList<>();
        cardViewModels.add("User_name");

        // Initialize ViewPager2 and set its adapter
        ViewPager2 viewPager = rootView.findViewById(R.id.view_pager2);
        Adapter cardViewAdapter = new Adapter(cardViewModels, requireContext());
        viewPager.setAdapter(cardViewAdapter);
        viewPager.setPadding(30, 0, 30, 0);

        return rootView;
    }

    // RecyclerView Adapter
    class Adapter extends RecyclerView.Adapter<Adapter.AdapterViewHolder> {
        private final List<String> cardViewModels;
        private final Context cardViewContext;

        public Adapter(List<String> cardViewModels, Context cardViewContext) {
            this.cardViewModels = cardViewModels;
            this.cardViewContext = cardViewContext;
        }

        @NonNull
        @Override
        public AdapterViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.card_view_item, parent, false);
            return new AdapterViewHolder(v);
        }

        @Override
        public void onBindViewHolder(@NonNull AdapterViewHolder holder, int position) {
            String cardViewItem = cardViewModels.get(position);
            holder.cardViewTitle.setText(cardViewItem);
        }

        @Override
        public int getItemCount() {
            return cardViewModels != null ? cardViewModels.size() : 0;
        }

        public class AdapterViewHolder extends RecyclerView.ViewHolder {
            TextView cardViewTitle;

            public AdapterViewHolder(View view) {
                super(view);
                cardViewTitle = view.findViewById(R.id.cardViewTitle);
            }
        }
    }
}